# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth.setup.js >> authenticate
- Location: tests\auth.setup.js:6:1

# Error details

```
Error: UMSYS_EMAIL / UMSYS_PASSWORD must be set
```

# Test source

```ts
  1  | import { test as setup, expect } from '@playwright/test';
  2  | import { SignInPage } from '../pages/sign-in-page.js';
  3  | 
  4  | const authFile = '.auth/user.json';
  5  | 
  6  | setup('authenticate', async ({ page }) => {
  7  |   const email = process.env.UMSYS_EMAIL;
  8  |   const password = process.env.UMSYS_PASSWORD;
  9  |   if (!email || !password) {
> 10 |     throw new Error('UMSYS_EMAIL / UMSYS_PASSWORD must be set');
     |           ^ Error: UMSYS_EMAIL / UMSYS_PASSWORD must be set
  11 |   }
  12 | 
  13 |   await page.goto('/sign-in');
  14 |   const signIn = new SignInPage(page);
  15 |   await signIn.login(email, password);
  16 | 
  17 |   await page.waitForURL(new RegExp(`/${email.replace(/[.@+]/g, '\\$&')}/?$`));
  18 |   await expect(page).toHaveURL(new RegExp(`/${email.replace(/[.@+]/g, '\\$&')}/?$`));
  19 |   await page.context().storageState({ path: authFile });
  20 | });
  21 | 
```